"""Source encoder, frozen class-weight anchors, temporal support and attention."""
from __future__ import annotations
from dataclasses import dataclass
import copy
import math
import torch
from torch import Tensor, nn
import torch.nn.functional as F
from .transport import cosine_anchor_cost, partial_unbalanced_sinkhorn, barcode_from_plan


class ConvEncoder(nn.Module):
    """Engineering realization of the paper's shared 1D-CNN: 64/128/128 channels.

    Kernel sizes and temporal pooling are implementation choices not fully fixed
    by the Methodology. The same architecture is used in source and target.
    """
    def __init__(self, channels: int, dimension: int = 128):
        super().__init__()
        widths = (64, 128, dimension)
        stages = []
        inc = channels
        for outc in widths:
            stages.extend([nn.Conv1d(inc, outc, 5, padding=2),
                           nn.BatchNorm1d(outc), nn.ReLU(), nn.AvgPool1d(2)])
            inc = outc
        self.network = nn.Sequential(*stages)
        self.dimension = dimension
        self.channels = channels

    def forward(self, x: Tensor) -> Tensor:
        if x.ndim != 3 or x.size(1) != self.channels:
            raise ValueError(f'Expected input [B,{self.channels},T], received {tuple(x.shape)}')
        if x.size(-1) < 8:
            raise ValueError('Input sequence must have T>=8')
        return self.network(x)  # B,D,Tenc


class SourceClassifier(nn.Module):
    def __init__(self, channels: int, classes: int, dimension: int = 128):
        super().__init__()
        self.encoder = ConvEncoder(channels, dimension)
        self.head = nn.Linear(dimension, classes)
        self.channels, self.classes, self.dimension = channels, classes, dimension

    def forward(self, x: Tensor) -> Tensor:
        return self.head(self.encoder(x).mean(dim=-1))


class TemporalEvidencePath(nn.Module):
    """Eq. pi, r, smoothed-r, biased QKV attention + gated residual and pooling."""
    def __init__(self, dimension: int = 128, patches: int = 16):
        super().__init__()
        self.dimension, self.patches = dimension, patches
        self.query = nn.Linear(dimension, dimension, bias=False)
        self.key = nn.Linear(dimension, dimension, bias=False)
        self.value = nn.Linear(dimension, dimension, bias=False)
        # Avoid arbitrary attention update at initialization; residual still active.
        nn.init.zeros_(self.value.weight)

    def segments(self, feature_map: Tensor) -> Tensor:
        # Partition the encoder time axis into NONOVERLAPPING patches.
        # End padding is a documented implementation choice for L % n != 0.
        B, D, L = feature_map.shape
        n = min(self.patches, L)
        patch_width = math.ceil(L / n)
        extra = n * patch_width - L
        if extra:
            feature_map = F.pad(feature_map, (0, extra), mode='replicate')
        return feature_map.reshape(B, D, n, patch_width).mean(-1).transpose(1, 2)

    @staticmethod
    def support(segments: Tensor, barcode: Tensor, anchors: Tensor,
                kappa: float, sigma: float) -> tuple[Tensor, Tensor, Tensor]:
        if kappa <= 0 or sigma <= 0:
            raise ValueError('kappa and sigma must be positive')
        pi = torch.softmax(
            torch.matmul(F.normalize(segments, dim=-1), F.normalize(anchors, dim=-1).T) / kappa,
            dim=-1)
        local = torch.sum(barcode[:, None, :] * pi, dim=-1)
        t = torch.arange(local.shape[1], device=local.device, dtype=local.dtype)
        kernel = torch.exp(-torch.abs(t[:, None] - t[None, :]) / sigma)
        kernel = kernel / kernel.sum(dim=-1, keepdim=True)
        smooth = local @ kernel.T
        return pi, local, smooth

    def pool(self, segments: Tensor, smoothed_support: Tensor, deficiency: Tensor,
             lambda_b: float = 1.0, lambda_u: float = 0.3) -> tuple[Tensor, Tensor]:
        q, k, v = self.query(segments), self.key(segments), self.value(segments)
        D = segments.shape[-1]
        bias = lambda_b * smoothed_support[:, :, None] * smoothed_support[:, None, :]
        scores = torch.matmul(q, k.transpose(1, 2)) / math.sqrt(D) + bias
        context = torch.matmul(torch.softmax(scores, -1), v)
        gate = torch.exp(-lambda_u * deficiency)[:, None, None]
        segment_out = segments + gate * context
        weights = torch.softmax(smoothed_support, dim=-1)
        pooled = torch.sum(weights[:, :, None] * segment_out, dim=1)
        return pooled, weights


@dataclass
class MethodConfig:
    epsilon: float = 0.05
    tau: float = 1.0
    sigma: float = 2.0
    gamma_s: float = 0.55
    gamma_u: float = 0.45
    lambda_b: float = 1.0
    lambda_u: float = 0.3
    lambda_ca: float = 0.1
    # The paper does not specify numerical values for these parameters.
    kappa: float = 0.2
    eta: float = 0.5
    nu: float = 1.0
    mu: float = 0.1
    patches: int = 16
    views: int = 2
    low_fraction: float = 0.25
    perturbation: str = 'mask'  # 'mask' / 'jitter' / 'frequency'
    jitter_std: float = 0.1
    transport_steps: int = 150


class CWBT2E(nn.Module):
    def __init__(self, pretrained: SourceClassifier, cfg: MethodConfig):
        super().__init__()
        self.config = cfg
        self.encoder = copy.deepcopy(pretrained.encoder)
        self.classifier = copy.deepcopy(pretrained.head)
        for p in self.classifier.parameters():
            p.requires_grad_(False)
        self.classifier.eval()
        self.path = TemporalEvidencePath(pretrained.dimension, cfg.patches)
        self.channels, self.classes = pretrained.channels, pretrained.classes
        self.dimension = pretrained.dimension

    def train(self, mode: bool = True):
        super().train(mode)
        self.classifier.eval()  # never change the released source hypothesis
        return self

    @torch.no_grad()
    def cues(self, sequence_repr: Tensor, segments: Tensor) -> dict[str, Tensor]:
        c = cosine_anchor_cost(sequence_repr, self.classifier.weight)
        P = partial_unbalanced_sinkhorn(
            c, self.config.epsilon, self.config.tau,
            self.config.transport_steps)
        info = barcode_from_plan(P, self.config.gamma_s, self.config.gamma_u)
        pi, local, smooth = self.path.support(
            segments.detach(), info['barcode'], self.classifier.weight,
            self.config.kappa, self.config.sigma)
        return {**info, 'plan': P, 'pi': pi, 'local_support': local,
                'smooth_support': smooth, 'cost': c}

    def reference(self, x: Tensor) -> tuple[Tensor, dict[str, Tensor]]:
        features = self.encoder(x)
        seg = self.path.segments(features)
        # Transport plan / barcode and evidence profiles are fixed for this step.
        cues = self.cues(features.mean(-1).detach(), seg.detach())
        pooled, alpha = self.path.pool(seg, cues['smooth_support'],
                                       cues['deficiency'],
                                       self.config.lambda_b, self.config.lambda_u)
        logits = self.classifier(pooled)
        return logits, {**cues, 'attention_weights': alpha}

    def view_logits(self, perturbed: Tensor, reference_cues: dict[str, Tensor]) -> Tensor:
        seg = self.path.segments(self.encoder(perturbed))
        # Recalculate segment-to-anchor compatibility for this view, but hold
        # the sequence-level transport and class barcode fixed as in Alg. 1.
        with torch.no_grad():
            _, _, smooth = self.path.support(
                seg.detach(), reference_cues['barcode'], self.classifier.weight,
                self.config.kappa, self.config.sigma)
        pooled, _ = self.path.pool(seg, smooth, reference_cues['deficiency'],
                                   self.config.lambda_b, self.config.lambda_u)
        return self.classifier(pooled)

    def forward(self, x: Tensor) -> Tensor:
        return self.reference(x)[0]
