"""Equation-aligned pseudo-label, calibration, and intervention losses."""
from __future__ import annotations
import math
import torch
from torch import Tensor
import torch.nn.functional as F


def evidence_weighted_self_training(logits: Tensor, cues: dict[str, Tensor],
                                    eta: float, mu: float,
                                    delta: float = 1e-8) -> dict[str, Tensor]:
    """Eq. yhat, omega, and J_ew; full batch is used by calibration term."""
    if not 0 <= eta <= 1:
        raise ValueError('eta must be in [0,1]')
    probs = F.softmax(logits, dim=-1)
    b = cues['barcode'].detach()
    selected = cues['indicator'].detach()
    s = cues['concentration'].detach()
    u = cues['deficiency'].detach()
    with torch.no_grad():
        pseudo = (eta * probs.detach() + (1-eta) * b).argmax(dim=-1)
        H = -(b * b.clamp_min(delta).log()).sum(-1)
        weight = selected * s * (1-u) * torch.exp(-H)
    picked_log_p = F.log_softmax(logits, dim=-1).gather(1, pseudo[:, None]).squeeze(1)
    pseudo_loss = (-weight * picked_log_p).mean()
    cond_ent = -(probs * probs.clamp_min(delta).log()).sum(-1).mean()
    pbar = probs.mean(0)
    batch_negative_ent = (pbar * pbar.clamp_min(delta).log()).sum()
    calibration = cond_ent + batch_negative_ent
    loss = pseudo_loss + mu * calibration
    return dict(loss=loss, pseudo_loss=pseudo_loss, calibration=calibration,
                pseudo=pseudo, weight=weight, selected=selected)


def intervention_consistency(reference_logits: Tensor,
                             view_logits: list[Tensor],
                             selected: Tensor, nu: float,
                             eps: float = 1e-8) -> Tensor:
    """Paper: ||logits_ref - logits_view_1||^2 + nu/M * sum KL(p_ref||p_m).

    The comparison is masked by I_i but divided by entire minibatch B.
    Only FIRST intervention view participates in squared-logit term.
    """
    if not view_logits:
        return reference_logits.sum() * 0
    logit_diff = (reference_logits - view_logits[0]).square().sum(dim=-1)
    p_ref = F.softmax(reference_logits, -1).clamp_min(eps)
    log_p_ref = torch.log(p_ref)
    kl_terms = []
    for view in view_logits:
        log_p_view = F.log_softmax(view, -1)
        kl_terms.append((p_ref * (log_p_ref - log_p_view)).sum(dim=-1))
    per_sequence = logit_diff + nu * torch.stack(kl_terms).mean(0)
    return (selected * per_sequence).mean()


def build_low_support_mask(support: Tensor, selected: Tensor,
                           original_length: int, low_fraction: float) -> Tensor:
    """Map bottom fraction of T' support patches onto input time intervals.

    Boundaries are an engineering choice; original text does not prescribe the
    exact selection fraction, so it is configurable.
    """
    if not 0 < low_fraction < 1:
        raise ValueError('low_fraction must be between 0 and 1')
    B, S = support.shape
    count = max(1, min(S-1, int(math.ceil(S * low_fraction)))) if S > 1 else 1
    index = support.topk(count, dim=1, largest=False).indices
    region = torch.zeros_like(support, dtype=torch.bool)
    region.scatter_(1, index, True)
    region &= (selected > 0)[:, None]
    # floor(t*S/T) assigns each raw time sample to a patch.
    timesteps = torch.arange(original_length, device=support.device)
    patch_ids = torch.div(timesteps * S, original_length, rounding_mode='floor').clamp(max=S-1)
    return region[:, patch_ids]  # B,T


@torch.no_grad()
def perturb_low_support(x: Tensor, mask: Tensor,
                        kind: str = 'mask', jitter_std: float = 0.1) -> Tensor:
    """Perturb only candidate low-support samples; high support is untouched.

    'frequency' attenuates selected frequency magnitudes while retaining the
    original phases of remaining frequency coefficients (local-window FFT).
    Implementation choice: uses the temporal bounding window of selected points.
    """
    out = x.clone()
    B, C, T = x.shape
    if mask.shape != (B, T):
        raise ValueError('mask shape should be [B,T]')
    full_mask = mask.unsqueeze(1).expand(-1, C, -1)
    if kind == 'mask':
        return torch.where(full_mask, torch.zeros_like(x), x)
    if kind == 'jitter':
        noise = jitter_std * torch.randn_like(x)
        return torch.where(full_mask, x + noise, x)
    if kind == 'frequency':
        for i in range(B):
            idx = torch.where(mask[i])[0]
            if idx.numel() < 4:
                continue
            # Frequency dropout is applied separately to each contiguous region.
            split = (idx[1:] != idx[:-1]+1).nonzero().flatten() + 1
            boundaries = [p for p in torch.tensor_split(idx, split.tolist()) if p.numel() >= 4]
            for position in boundaries:
                lo, hi = int(position[0]), int(position[-1]) + 1
                original = x[i, :, lo:hi]
                spectrum = torch.fft.rfft(original, dim=-1)
                # Retain phase of non-dropped coefficients; leave DC unchanged.
                atten = torch.ones_like(spectrum.real)
                if atten.shape[-1] > 2:
                    atten[..., 1:] = (torch.rand_like(atten[..., 1:]) > 0.2).to(atten.dtype)
                spectrum = spectrum * atten
                out[i, :, lo:hi] = torch.fft.irfft(spectrum, n=hi-lo, dim=-1)
        return out
    raise ValueError(f'Unknown perturbation mode: {kind}')
