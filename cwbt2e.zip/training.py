"""Source-supervised pretraining and source-free target adaptation (Algorithm 1)."""
from __future__ import annotations
import random
import numpy as np
import torch
from torch import Tensor, nn
from torch.utils.data import DataLoader, TensorDataset
from .model import SourceClassifier, CWBT2E, MethodConfig
from .losses import (evidence_weighted_self_training, build_low_support_mask,
                     perturb_low_support, intervention_consistency)


def seed_everything(seed: int) -> None:
    random.seed(seed)
    np.random.seed(seed)
    torch.manual_seed(seed)
    if torch.cuda.is_available():
        torch.cuda.manual_seed_all(seed)


def source_epoch(model: SourceClassifier, loader: DataLoader,
                 optimizer: torch.optim.Optimizer, device: str) -> float:
    model.train()
    total, batches = 0., 0
    for x, y in loader:
        x, y = x.to(device), y.long().to(device)
        logits = model(x)
        loss = nn.functional.cross_entropy(logits, y)
        optimizer.zero_grad(set_to_none=True)
        loss.backward()
        optimizer.step()
        total, batches = total + float(loss.detach()), batches + 1
    return total / max(1,batches)


def target_step(model: CWBT2E, inputs: Tensor,
                optimizer: torch.optim.Optimizer) -> dict[str, float]:
    """One alternating PUOT / gradient update from the paper's Algorithm 1.

    No source observations/labels or target labels are passed into this function.
    """
    model.train()
    cfg = model.config
    x = inputs
    logits, cues = model.reference(x)
    ew = evidence_weighted_self_training(logits, cues, cfg.eta, cfg.mu)
    mask = build_low_support_mask(cues['smooth_support'], cues['indicator'],
                                  x.shape[-1], cfg.low_fraction)
    # No unnecessary forward passes if no evidence-selected sequences.
    views = []
    if bool(cues['indicator'].any().item()) and cfg.lambda_ca != 0:
        for _ in range(cfg.views):
            x_view = perturb_low_support(x, mask, cfg.perturbation, cfg.jitter_std)
            views.append(model.view_logits(x_view, cues))
    reg = intervention_consistency(logits, views, cues['indicator'], cfg.nu)
    objective = ew['loss'] + cfg.lambda_ca * reg
    optimizer.zero_grad(set_to_none=True)
    objective.backward()
    optimizer.step()
    return dict(objective=float(objective.detach()),
                pseudo=float(ew['pseudo_loss'].detach()),
                calibration=float(ew['calibration'].detach()),
                intervention=float(reg.detach()),
                selected_rate=float(cues['indicator'].mean()),
                mean_support=float(cues['normalized_mass'].mean()))


def target_epoch(model: CWBT2E, loader: DataLoader,
                 optimizer: torch.optim.Optimizer, device: str) -> dict[str, float]:
    totals: dict[str, float] = {}
    steps = 0
    for (x,) in loader:
        stats = target_step(model, x.to(device), optimizer)
        for name, value in stats.items():
            totals[name] = totals.get(name,0.)+value
        steps += 1
    return {name: value / max(steps,1) for name,value in totals.items()}


def make_loader(x: np.ndarray, y: np.ndarray | None = None,
                batch_size: int = 32, shuffle: bool = True) -> DataLoader:
    x = np.asarray(x, dtype=np.float32)
    if x.ndim != 3:
        raise ValueError('x must have [N,C,T] dimensions')
    if y is not None:
        y = np.asarray(y, dtype=np.int64)
        if y.shape != (len(x),):
            raise ValueError('y must have [N] dimension')
        ds = TensorDataset(torch.from_numpy(x), torch.from_numpy(y))
    else:
        ds = TensorDataset(torch.from_numpy(x))
    return DataLoader(ds, batch_size=batch_size, shuffle=shuffle, drop_last=False)


def evaluate(model: nn.Module, loader: DataLoader, device: str) -> dict[str, float]:
    """Held-out labels are used only in this evaluation call, never adaptation."""
    from sklearn.metrics import accuracy_score, f1_score
    model.eval()
    guesses, truths = [], []
    with torch.no_grad():
        for x,y in loader:
            out = model(x.to(device))
            guesses.append(out.argmax(1).cpu().numpy())
            truths.append(y.numpy())
    y_true, y_pred = np.concatenate(truths), np.concatenate(guesses)
    return dict(accuracy=float(accuracy_score(y_true,y_pred)),
                macro_f1=float(f1_score(y_true,y_pred,average='macro',zero_division=0)))
