"""Partially unbalanced OT for Eq. (PUOT): KL row-marginal penalty, exact columns.

No sklearn/POT dependency. The log-domain updates implement generalized Sinkhorn.
The returned transport is not differentiated through during alternating adaptation.
"""
from __future__ import annotations

import torch
from torch import Tensor
import torch.nn.functional as F


def cosine_anchor_cost(features: Tensor, weights: Tensor) -> Tensor:
    """features [B,D], frozen classifier weights [K,D] -> C [B,K].

    The classifier bias is deliberately not used in geometric matching.
    """
    return 1 - F.normalize(features, dim=-1) @ F.normalize(weights, dim=-1).T


@torch.no_grad()
def partial_unbalanced_sinkhorn(
    cost: Tensor, epsilon: float = 0.05, tau: float = 1.0,
    iterations: int = 150, tolerance: float = 1e-6,
) -> Tensor:
    r"""Solve min_P <P,C> + eps sum P(logP-1) + tau KL(P1||r)
    subject to P.T 1 = q, P >= 0, r_i=1/B, q_k=1/K.

    KL is generalized KL: sum_i [rho_i log(rho_i/r_i)-rho_i+r_i].
    Exact anchor marginal holds to numerical precision at convergence.
    All log-domain calculations run in float64 for small entropic epsilon.
    """
    if cost.ndim != 2 or not torch.isfinite(cost).all():
        raise ValueError('cost must be a finite [B,K] matrix')
    if epsilon <= 0 or tau <= 0 or iterations < 1:
        raise ValueError('epsilon, tau and iterations must be positive')
    B, K = cost.shape
    if B < 1 or K < 2:
        raise ValueError('Require B>=1 and K>=2')
    log_kernel = -cost.detach().to(torch.float64) / epsilon
    log_r = -torch.log(torch.tensor(float(B), device=cost.device, dtype=torch.float64))
    log_q = -torch.log(torch.tensor(float(K), device=cost.device, dtype=torch.float64))
    a = tau / (tau + epsilon)
    log_u = torch.zeros(B, device=cost.device, dtype=torch.float64)
    log_v = torch.zeros(K, device=cost.device, dtype=torch.float64)
    for it in range(iterations):
        u = a * (log_r - torch.logsumexp(log_kernel + log_v[None, :], dim=1))
        v = log_q - torch.logsumexp(log_kernel + u[:, None], dim=0)
        if it % 5 == 0 and max(torch.max(torch.abs(u - log_u)).item(),
                               torch.max(torch.abs(v - log_v)).item()) < tolerance:
            log_u, log_v = u, v
            break
        log_u, log_v = u, v
    log_plan = log_kernel + log_u[:, None] + log_v[None, :]
    plan = torch.exp(log_plan)
    if not torch.isfinite(plan).all():
        raise RuntimeError('Transport failed to yield a finite plan')
    # Enforce column marginal within floating-point resolution after casting.
    plan = plan * ((1.0 / K) / plan.sum(dim=0).clamp_min(1e-300))[None, :]
    return plan.to(dtype=cost.dtype)


def barcode_from_plan(plan: Tensor, gamma_s: float = 0.55,
                      gamma_u: float = 0.45, delta: float = 1e-8) -> dict[str, Tensor]:
    """Paper's rho, rho_hat, barcode, s, u, and binary I definitions."""
    B, K = plan.shape
    row_mass = plan.sum(1)
    norm_mass = (row_mass * B).clamp(max=1.0)
    barcode = plan / (row_mass[:, None] + delta)
    concentration = barcode.max(1).values
    deficiency = 1.0 - norm_mass * concentration
    indicator = ((concentration > gamma_s) & (deficiency < gamma_u)).to(plan.dtype)
    return dict(row_mass=row_mass, normalized_mass=norm_mass, barcode=barcode,
                concentration=concentration, deficiency=deficiency, indicator=indicator)
