"""CWBT2E: paper-aligned implementation for source-free time-series adaptation."""
from .model import SourceClassifier, CWBT2E, MethodConfig
from .transport import cosine_anchor_cost, partial_unbalanced_sinkhorn, barcode_from_plan
from .training import source_epoch, target_epoch, target_step, seed_everything

__all__ = ['SourceClassifier', 'CWBT2E', 'MethodConfig',
           'cosine_anchor_cost', 'partial_unbalanced_sinkhorn',
           'barcode_from_plan', 'source_epoch', 'target_epoch',
           'target_step', 'seed_everything']
